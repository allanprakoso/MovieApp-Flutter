abstract class Mapper<I, O> {
  O map(I input);
}
